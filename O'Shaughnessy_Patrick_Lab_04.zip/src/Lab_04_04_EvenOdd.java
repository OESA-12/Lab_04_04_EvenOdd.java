public class Lab_04_04_EvenOdd
{
    public static void main(String[] args)
    {
        int evenNumber = 3;
        if (evenNumber % 2 == 0) {
            System.out.println(evenNumber + " is even ");
        } else {
            System.out.println(evenNumber + " is odd");
        }
        }
}
